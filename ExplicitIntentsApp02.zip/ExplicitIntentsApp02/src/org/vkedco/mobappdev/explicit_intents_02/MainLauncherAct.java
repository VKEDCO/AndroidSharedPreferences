package org.vkedco.mobappdev.explicit_intents_02;

/*
 * ********************************************
 * 
 * MainLauncherAct.java - main activity of
 * ExplicitIntentsApp02 app. Shows how to create an
 * explicit intent and add a key-value pair to it.
 * MainLauncherAct specifies to ImageDisplayerAct02 which
 * image to display.
 * 
 * Bugs to vladimir dot kulyukin at gmail dot com
 * ********************************************
 */

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
import java.util.Random;

public class MainLauncherAct extends Activity {

	protected Button mBtnDisplay = null;
	protected Activity mThisAct = null;
	protected Resources mRes = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_launcher);
        mBtnDisplay = (Button) this.findViewById(R.id.btn_display);
        mThisAct = this;
        mRes = getResources();
        
        mBtnDisplay.setOnClickListener(
        		new OnClickListener() {

					@Override
					public void onClick(View v) {
						// 1. Create an explicit intent
						Intent i = new Intent(mThisAct, ImageDisplayerAct02.class);
						// 2. Generate a random number in [1, 8]
						int random_img_id = new Random().nextInt(8) + 1;
						// 3. Put key-value pair into the intent.
						i.putExtra(mRes.getString(R.string.img_id_key), random_img_id);
						// 4. Toast which image is requested.
						Toast.makeText(mThisAct, 
								mRes.getString(R.string.img_display_request_msg) + " " 
								+ random_img_id,
								Toast.LENGTH_SHORT).show();
						// 5. Request Android to run it.
						startActivity(i);
					}	
        		}
        );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main_launcher, menu);
        return true;
    }
}
